Assign3:
~ 1. Compiling the program ~ 
Prior to compiling the program, one must cd into the directory where the .java files are saved. Ensure that 
the files Assign3.java, BinaryTree.java, Data.java, Node.java, and Queue.java are present. Then to compile the files, the 
following command should be ran:
javac *.java

~ 2. Running the program ~ 
Once again, prior to running the program one must check that the input text file(s) are in a "src" subfolder present in the same 
directory as where the .java files are saved. Why do they need to be in a "src" subfolder? No idea. I can't explain this, and
the string "src" is no where in my program. I am very confused, but if the input text file(s) are in a "src" subfolder then
it works. To run the program, the following command should be used:
java Assign3 inputFileName depthFirstFileName breadthFirstFileName

Note: In time of actual use, replace the word inputFileName, depthFirstFileName, and breadthFirstFileName with the
appropriate text file name that you are wishing to use. The extension .txt should not be added to the end of the text file name.


Assign3b (Bonus Component)
~ 1. Compiling the program ~ 
Prior to compiling the program, one must cd into the directory where the .java files are saved. Ensure that 
the files Assign3b.java, BinaryTree.java, AVLTree.java, Data.java, Node.java, and Queue.java are present. Then to compile the files, the 
following command should be ran:
javac *.java

~ 2. Running the program ~ 
Once again, prior to running the program one must check that the input text file(s) are in a "src" subfolder present in the same 
directory as where the .java files are saved. Why do they need to be in a "src" subfolder? No idea. I can't explain this, and
the string "src" is no where in my program. I am very confused, but if the input text file(s) are in a "src" subfolder then
it works. To run the program, the following command should be used:
java Assign3b inputFileName depthFirstFileName breadthFirstFileName

Note: In time of actual use, replace the word inputFileName, depthFirstFileName, and breadthFirstFileName with the
appropriate text file name that you are wishing to use. The extension .txt should not be added to the end of the text file name.